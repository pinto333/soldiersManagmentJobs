export interface Soldier {
  id: number;
  name: string;
}

export interface Job {
  id: number;
  date: string;
  text: string;
  selectedSoldiers: any [];
  dropDownUnSelectedSoldiers: Object [];
}

