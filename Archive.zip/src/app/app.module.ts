import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { HttpClientModule } from '@angular/common/http'
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { ButtonComponent } from './components/button/button.component';
import { JobsComponent } from './components/jobs/jobs.component';
import { JobItemComponent } from './components/Job-item/job-item.component';
import { AddJobComponent } from './components/add-job/add-job.component';
import { AddSoldierComponent } from './components/add-soldier/add-soldier.component';
import { DelBtnDirective } from './directives/del-btn.directive';
import { SelectSoldierNamePipe } from './pipes/soldier.pipe';
import { AboutComponent } from './components/about/about.component';
import { FooterComponent } from './components/footer/footer.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ButtonComponent,
    JobsComponent,
    JobItemComponent,
    AddJobComponent,
    AddSoldierComponent,
    DelBtnDirective,
    SelectSoldierNamePipe,
    AboutComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    FontAwesomeModule,
    HttpClientModule,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
