import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UiService {

  private showAddJob: boolean = false;
  private addJobSubject = new Subject<any>();

  private showAddSoldier: boolean = false;
  private addSoldierSubject = new Subject<any>()


  toggleAddJob() {
    this.showAddJob = !this.showAddJob;
    this.addJobSubject.next(this.showAddJob);
  }
  onToggleAddJob(): Observable<any> {
    return this.addJobSubject.asObservable();
  }

  toggleAddSoldier() {
    this.showAddSoldier = !this.showAddSoldier;
    this.addSoldierSubject.next(this.showAddSoldier);
  }
  onToggleAddSoldier(): Observable<any> {
    return this.addSoldierSubject.asObservable();
  }
}
