
import { Soldier, Job} from '../model/interfaces'

export let SOLDIERS: Soldier[] =  [
  { id:0, name:"Choose a Soldier"},
  { id:1, name:"Alon" },
  { id:2, name:"Joe" },
  { id:3, name:"Dud" },
  { id:4, name:"John" },
  { id:5, name:"Avi"},
  { id:6, name:"Willy"}
];

export let TASKS: string[] = [
  "Choose a Task",
  "Emptying safes at Bank Hapoalim",
  "Emptying safes at Bank Leumi",
  "Personal Security",
  "Collection of sponsorship"
];

export let JOBS: Job[] = [
  {
    id: 1,
    text: "Emptying safes at Bank Hapoalim",
    date: "Dec 29th at 2:30pm",
    selectedSoldiers: [
      { name: "Alon", id: 1 },
      { name: "Avi", id: 5 },
      { name: "Dud", id: 3 }
    ],
    dropDownUnSelectedSoldiers:[
      { name: "Joe", id: 2 },
      { name: "John", id: 4 },
      { name: "Willy", id: 6 }
    ]
  },
  {
    id: 2,
    text: "Emptying safes at Bank Leumi",
    date: "Dec 30th at 2:30pm",
    selectedSoldiers: [
      { name: "Joe", id: 2 },
      { name: "John", id: 4 },
      { name: "Alon", id: 1 }
    ],
    dropDownUnSelectedSoldiers:[
      { name: "Dud", id: 3 },
      { name: "Avi", id: 5 },
      { name: "Willy", id: 6 }
    ]
  },
  {
    id: 3,
    text: "Collection of sponsorship",
    date: "Dec 29th at 9:30pm",
    selectedSoldiers: [
      { name: "Willy", id: 6 },
      { name: "Avi", id: 5 },
      { name: "Alon", id: 1 }
    ],
    dropDownUnSelectedSoldiers:[
      { name: "Dud", id: 3 },
      { name: "Avi", id: 2 },
      { name: "Willy", id: 6 }
    ]
  },
  {
    id: 4,
    text: "Personal Security",
    date: "Dec 30th at 10:30pm",
    selectedSoldiers: [
      { name: "Joe", id: 2 },
      { name: "John", id: 5 }
    ],
    dropDownUnSelectedSoldiers: [
    { name: "Dud", id: 3 },
    { name: "Avi", id: 5 },
    { name: "John", id: 4 },
    { name: "Alon", id: 1 }
    ]
  }
];
