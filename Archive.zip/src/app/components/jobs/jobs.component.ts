import { Component, OnInit } from '@angular/core';
import { JOBS, SOLDIERS, TASKS } from '../../data/mock-jobs';
import { Job, Soldier } from '../../model/interfaces';

@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.css'],
})
export class JobsComponent implements OnInit {

  private jobs: Job[];
  private tasks: string[];
  private soldiers: Soldier[];

  ngOnInit(): void {
    this.jobs = JOBS;
    this.tasks = TASKS;
    this.soldiers = SOLDIERS;
  }

  deleteJob(job: Job) {
    this.jobs = this.jobs.filter(_job => _job.id != job.id)
  }
  addJob(job: any) {
    this.jobs =  [...this.jobs, job];
  }
  addSoldier(soldier: Soldier){
      this.soldiers =  [...this.soldiers, soldier]
  }

  getJobs(){ return this.jobs;}
  getTasks() { return this.tasks; }
  getSoldiers() { return this.soldiers; }

}

