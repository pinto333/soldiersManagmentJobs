import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Job } from '../../model/interfaces';


@Component({
  selector: 'app-job-item',
  templateUrl: './job-item.component.html',
  styleUrls: ['./job-item.component.css'],
})
export class JobItemComponent {
  @Input() job: Job;
  @Output() onDeleteJob: EventEmitter<Job> = new EventEmitter();

  onDelete(job:Job) {
    this.onDeleteJob.emit(job);
  }
}

