import { Component } from '@angular/core';
import { Subscription } from 'rxjs';
import { UiService } from '../../services/ui.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  title : string = 'Work Assignment';
  showAddJob: boolean = false;
  showAddSoldier: boolean = false;
  addJobSubscription: Subscription;
  addSoldierSubscription: Subscription;


  constructor(private uiService: UiService) {
    this.addJobSubscription = this.uiService
        .onToggleAddJob()
        .subscribe((value) => (this.showAddJob = value));
    this.addSoldierSubscription = this.uiService
        .onToggleAddSoldier()
        .subscribe((value) => (this.showAddSoldier = value));
  }

  ngOnDestroy() {
    // Unsubscribe to ensure no memory leaks
    this.addJobSubscription.unsubscribe();
    this.addSoldierSubscription.unsubscribe();

  }

 toggleAddJob() { this.uiService.toggleAddJob(); }
 toggleAddSoldier() { this.uiService.toggleAddSoldier();}

}
