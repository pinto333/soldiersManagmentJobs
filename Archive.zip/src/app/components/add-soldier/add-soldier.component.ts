import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Subscription } from 'rxjs';
import { Soldier } from 'src/app/model/interfaces';
import { UiService } from 'src/app/services/ui.service';

@Component({
  selector: 'app-add-soldier',
  templateUrl: './add-soldier.component.html',
  styleUrls: ['./add-soldier.component.css']
})
export class AddSoldierComponent implements OnInit {
  @Output() onAddSoldier: EventEmitter<Soldier> = new EventEmitter();
  @Input() soldiers: Soldier[];

  private newSoldierId: number;
  showAddSoldier: boolean;

  name: string;
  subscription: Subscription;


  constructor(private uiService: UiService) {
    this.subscription = this.uiService.onToggleAddSoldier().subscribe(value => {
      this.showAddSoldier = value;
      this.name = '';
      })
    }

  ngOnInit() {
    this.newSoldierId = this.getNewId();
  }
  getNewId(): number {
      const MaxSoldierId =  this.soldiers.reduce((prev, current) => (prev.id > current.id) ? prev : current)
      return MaxSoldierId.id + 1;
    }
   ngOnDestroy() {  this.subscription.unsubscribe(); }

  onSubmit() {
    if (!this.name) {
      alert('Soldier is Require!');
      return;
    }
    const newSoldier = {
      id: this.newSoldierId++,
      name: this.name,
    }
    this.onAddSoldier.emit(newSoldier);
    this.name = '';
    }
  }

