import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { UiService } from '../../services/ui.service';
import { Subscription } from 'rxjs';
import { Job, Soldier } from '../../model/interfaces';

@Component({
  selector: 'app-add-job',
  templateUrl: './add-job.component.html',
  styleUrls: ['./add-job.component.css'],
})
export class AddJobComponent implements OnInit {
  @Output() onAddJob: EventEmitter<Job> = new EventEmitter();
  @Input() tasks: string[];
  @Input() jobs: Job[];
  @Input() soldiers: Soldier[];

  private newJobId: number;
  subscription: Subscription;
  showAddJob: boolean;
  text:string;
  date: string;

  selectedTasks: string [];
  dropDownUnSelectedTasks: string [];
  dropDownUnSelectedSoldiers: Soldier[];
  selectedSoldiers: Soldier[];
  selectedSoldiersByName: string[];

  constructor(private uiService: UiService) {
    this.subscription = this.uiService.onToggleAddJob().subscribe((value) => {
      this.showAddJob = value;
      this.formReset();
      this.resetData();
    });
  }

  ngOnInit(): void {
    this.newJobId = this.getNewId();
    this.resetData();
  }
  ngOnDestroy() {  this.subscription.unsubscribe(); }

  resetData() {
    this.dropDownUnSelectedTasks = this.tasks;
    this.dropDownUnSelectedSoldiers =this.soldiers;
    this.selectedSoldiers = this.selectedSoldiersByName = this.selectedTasks =[];
  }
  getNewId(): number {
    const MaxSoldierId =  this.soldiers.reduce((prev, current) => (prev.id > current.id) ? prev : current)
    return MaxSoldierId.id + 1;
  }

  onSubmit() {
    if (!this.text) {
      alert('Task is Require!');
      return;
    }
    const taskExist = this.tasks.find(task => this.text == task);
    if (this.text !== undefined && !taskExist && this.tasks.length <= 10) {
      this.tasks = [...this.tasks,this.text]
    }
    this.onAddJob.emit(this.newJob());
    this.formReset();
    this.resetData();
    console.log('tasks =',this.tasks);
    console.log('jobs =',this.jobs)
    console.log('soldiers =',this.soldiers)
  }

  onChooseSoldier(soldierName: any){
    const _soldierName = soldierName.target.value;
    const soldier =  this.dropDownUnSelectedSoldiers.find(_soldier => _soldier.name === _soldierName);
    if (soldier === undefined) {
      return  }
    this.dropDownUnSelectedSoldiers = this.dropDownUnSelectedSoldiers.filter(_soldier => soldier.id !== _soldier.id);
    const soldierExist = this.soldiers.find(_soldier => _soldier.name == soldier.name);
    if (!soldierExist && this.soldiers.length <= 10) {
      this.selectedSoldiers = [...this.selectedSoldiers, soldier];
    }
    this.selectedSoldiersByName = [...this.selectedSoldiersByName, soldier.name];
  }
  onChooseTask(task: any){
    this.dropDownUnSelectedTasks = this.dropDownUnSelectedTasks.filter(_task => _task !== task.target.value);
    this.selectedTasks = [...this.selectedTasks, task.target.value ]

  }
  newJob() {console.log('newJob'); return {
      id: ++this.newJobId,
      text: this.text,
      date: this.date,
      selectedSoldiers: this.selectedSoldiers,
      dropDownUnSelectedSoldiers: this.dropDownUnSelectedSoldiers,
  }};

  formReset(){
    this.date = this.text = ''
    this.selectedSoldiers =  this.dropDownUnSelectedSoldiers = [];
  }
}
