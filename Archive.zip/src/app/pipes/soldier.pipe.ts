import { identifierModuleUrl } from '@angular/compiler';
import { Pipe, PipeTransform } from '@angular/core';
import { Soldier } from '../model/interfaces';

@Pipe({
  name: 'selectSoldierName'
})
export class SelectSoldierNamePipe implements PipeTransform {

  transform(value: Soldier[] , selected='!'): string {
    let soldierNames = 'Soldiers: ';
    value.map(item => soldierNames += item.name + ' ' )
    return soldierNames;
  }

}
