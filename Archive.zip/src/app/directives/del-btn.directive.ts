import { Directive, HostBinding, HostListener, OnInit } from '@angular/core';

@Directive({
  selector: '[appDelBtn]'
})
export class DelBtnDirective implements OnInit {

  @HostBinding('style.color') color = 'red';
  @HostBinding('style.color') background = '#aba7a7';
  @HostListener('mouseOver') changeColor() { this.color = 'blue'; };


  constructor() { }

  ngOnInit() { }
}
